# RaiMoon - Forked

Current XRB price in menu bar, gets price every 5mins to match data refresh rate of [coinmarketcap](https://coinmarketcap.com).

Download RaiMoon: [Here](https://cdn.rawgit.com/schenkty/RaiMoon/9a1721b1/RaiMoon.zip)
