# RaiMoon - Forked

Current XRB price in menu bar, gets price every 5mins to match data refresh rate of [coinmarketcap](https://coinmarketcap.com).
