# RaiMoon - Forked

Current NANO price in menu bar, gets price every 5mins to match data refresh rate of [CoinMarketCap](https://coinmarketcap.com).

Download RaiMoon: [Here](https://cdn.rawgit.com/schenkty/RaiMoon/1a25be77/RaiMoon.zip)
